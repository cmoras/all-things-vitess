delete from corder;
delete from customer;
delete from product;