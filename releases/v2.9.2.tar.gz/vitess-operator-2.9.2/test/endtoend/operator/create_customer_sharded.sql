alter table customer change customer_id customer_id bigint not null;
alter table corder change order_id order_id bigint not null;
