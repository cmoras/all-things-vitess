\! echo 'Using customer/80-'
use customer/80-;
\! echo 'Customer'
select * from customer;
\! echo 'COrder'
select * from corder;
