\! echo 'Using commerce'
use commerce;
\! echo 'Customer'
select * from customer;
\! echo 'Product'
select * from product;
\! echo 'COrder'
select * from corder;
