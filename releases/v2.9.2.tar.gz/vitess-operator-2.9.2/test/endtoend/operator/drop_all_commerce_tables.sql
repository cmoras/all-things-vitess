drop table if exists customer;
drop table if exists corder;
drop table if exists product;